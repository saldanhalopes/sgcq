/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prati_sgcq.dao;

import javax.persistence.EntityManager;
import prati_sgcq.connection.ConnectionFactory;
import prati_sgcq.model.PostDetails;

/**
 *
 * @author rafael.lopes
 */
public class PostDetailsDAO {
    
    public PostDetails salvar(PostDetails cls) throws Exception {
        EntityManager em = ConnectionFactory.em(true);
        try {
            em.getTransaction().begin();
            if (cls.getId() == null) {
                em.persist(cls);
            } else {
                if (!em.contains(cls)) {
                    if (em.find(cls.getClass(), cls.getId()) == null) {
                        throw new Exception("Erro ao Atualizar!");
                    }
                }
                cls = em.merge(cls);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            em.getTransaction().rollback();
            throw new Exception(ex);
        } finally {
            em.close();
        }
        return cls;
    }
    
    public PostDetails findById(Class<PostDetails> cls, Integer id) throws Exception {
        EntityManager em = ConnectionFactory.em(true);
        PostDetails t = null;
        try {
            t = em.find(cls, id);
        } catch (Exception ex) {
            throw new Exception(ex);
        } finally {
            em.close();
        }
        return t;
    }
    
}
