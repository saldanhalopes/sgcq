/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prati_sgcq.audit;

import java.net.UnknownHostException;
import java.util.Date;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import org.hibernate.envers.RevisionListener;
import prati_sgcq.interfaces.Auditable;
import prati_sgcq.model.Usuario;

/**
 *
 * @author rafael.lopes
 */
public class AuditListener implements RevisionListener {

    @Override
    public void newRevision(Object revisionEntity) {
        String computador;
        Usuario user = new Usuario(Integer.parseInt(System.getProperty("user_id")));
        String userComputador = System.getProperty("user.name");
        try {
            computador = java.net.InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException ex1) {
            computador = "not found";
        }
        AuditRevision auditRevision = (AuditRevision) revisionEntity;
        auditRevision.setUltimaModificacaoPor(user);
        auditRevision.setUltimaModificacao(new Date());
        auditRevision.setComputador(computador);
        auditRevision.setUserComputador(userComputador);
    }

    @PrePersist
    public void setCreatedOn(Auditable auditable) {
        String computador;
        Usuario user = new Usuario(Integer.parseInt(System.getProperty("user_id")));
        String userComputador = System.getProperty("user.name");
        try {
            computador = java.net.InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException ex1) {
            computador = "not found";
        }
        Audit audit = auditable.getAudit();
        if (audit == null) {
            audit = new Audit();
            auditable.setAudit(audit);
        }
        audit.setCreatedOn(new Date());
        audit.setCreatedBy(user);
        audit.setComputador(computador);
        audit.setUserComputador(userComputador);
    }

    @PreUpdate
    public void setUpdatedOn(Auditable auditable) {
        String computador;
        Usuario user = new Usuario(Integer.parseInt(System.getProperty("user_id")));
        String userComputador = System.getProperty("user.name");
        try {
            computador = java.net.InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException ex1) {
            computador = "not found";
        }
        Audit audit = auditable.getAudit();
        audit.setUpdatedOn(new Date());
        audit.setUpdatedBy(user);
        audit.setComputador(computador);
        audit.setUserComputador(userComputador);
    }

}
