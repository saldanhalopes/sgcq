/*
 * Copyright (C) 2018 rafael.lopes
 *
 * Este programa é um software livre: você pode redistribuí-lo e / ou modificar
 * sob os termos da GNU General Public License, conforme publicado pela
 * a Free Software Foundation, seja a versão 3 da Licença, quanto
 * qualquer versão posterior.
 *
 * Este programa é distribuído na esperança de que seja útil,
 * mas SEM QUALQUER GARANTIA; sem a garantia implícita de
 * COMERCIALIZAÇÃO OU APTIDÃO PARA UM PROPÓSITO PARTICULAR. Veja o
 * GNU General Public License para obter mais detalhes.
 *
 * Você deve ter recebido uma cópia da GNU General Public License
 *  juntamente com este programa. Caso contrário, veja <http://www.gnu.org/licenses/>.
 */
package prati_sgcq.model;

import java.io.Serializable;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.MapsId;
//import javax.persistence.OneToOne;
//import javax.persistence.Table;
//import javax.persistence.Version;
//import prati_stock.interfaces.EntidadeBase;

/**
 *
 * @author rafael.lopes
 */
//@Entity
//@Table(name = "tb_reagente_config_2")
public class ReagenteConfig implements  Serializable {
//
//    private static final long serialVersionUID = 1L;
//
//    @Id
//    @Column(name = "id", updatable = false, nullable = false)
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Integer id;
//    
//    @OneToOne
//    @MapsId
//    private Reagente reagente;
//    
//    @Version
//    private int version;
//
//    @Column(name = "tipo_reagente")
//    private String tipoReagente;
//        
//    public ReagenteConfig() {
//    }
//
//    @Override
//    public Integer getId() {
//        return id;
//    }
//
//    public void setId(Integer id) {
//        this.id = id;
//    }
//
//    public Reagente getReagente() {
//        return reagente;
//    }
//
//    public void setReagente(Reagente reagente) {
//        this.reagente = reagente;
//    }
//
//    public int getVersion() {
//        return version;
//    }
//
//    public void setVersion(int version) {
//        this.version = version;
//    }
//
//    public String getTipoReagente() {
//        return tipoReagente;
//    }
//
//    public void setTipoReagente(String tipoReagente) {
//        this.tipoReagente = tipoReagente;
//    }
//    
//    
    
}
